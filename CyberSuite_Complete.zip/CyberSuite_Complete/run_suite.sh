#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║     CyberSuite - Complete Offensive Security Framework       ║
# ║     IntelliPen (Recon+Scan) + ExploitX (Exploitation)        ║
# ╚══════════════════════════════════════════════════════════════╝

TARGET=$1

if [ -z "$TARGET" ]; then
    echo "Usage: ./run_suite.sh http://TARGET"
    echo ""
    echo "Example: ./run_suite.sh http://demo.testfire.net"
    exit 1
fi

echo ""
echo "  [*] CyberSuite - Full Attack Chain"
echo "  [*] Target: $TARGET"
echo ""

# المرحلة الأولى: الكشف والفحص
echo "  [PHASE 1] IntelliPen - Reconnaissance & Vulnerability Scanning..."
cd intellipen
python3 intellipen_cli.py $TARGET
REPORT=$(ls -t intellipen_report_*.json 2>/dev/null | head -1)
cd ..

if [ -z "$REPORT" ]; then
    echo "  [-] IntelliPen scan failed. Exiting."
    exit 1
fi

echo ""
echo "  [+] IntelliPen scan complete. Report: intellipen/$REPORT"
echo ""

# المرحلة الثانية: الاستغلال
echo "  [PHASE 2] ExploitX - Exploitation..."
cd exploitx
python3 exploitx.py --report ../intellipen/$REPORT
cd ..

echo ""
echo "  [+] CyberSuite attack chain complete!"
echo "  [+] Reports saved in: intellipen/ and exploitx/reports/"
