# CyberSuite — منظومة الأمن السيبراني الهجومي الكاملة

## المكونات

| الأداة | الدور | الوصف |
|--------|-------|-------|
| **IntelliPen** | الكاشف | استطلاع ذكي + فحص ثغرات + تحليل AI |
| **ExploitX** | المستغِل | استغلال فعلي + توليد PoC + تقارير |

## التشغيل السريع

```bash
# تثبيت كلتا الأداتين
cd intellipen && sudo bash install.sh && cd ..
cd exploitx && sudo bash install.sh && cd ..

# تشغيل المنظومة الكاملة على هدف واحد
./run_suite.sh http://TARGET
```

## التشغيل المنفصل

```bash
# IntelliPen فقط (كشف)
cd intellipen && python3 intellipen_cli.py http://TARGET

# ExploitX فقط (استغلال من تقرير)
cd exploitx && python3 exploitx.py --report ../intellipen/intellipen_report.json

# ExploitX مباشر
cd exploitx && python3 exploitx.py --target http://TARGET --auto
```

## مواقع الاختبار

```bash
./run_suite.sh http://demo.testfire.net
./run_suite.sh http://testphp.vulnweb.com
./run_suite.sh http://localhost:8888  # VulnLab المحلي
```
